# Activity 1: Access Modifiers

# 1. username: public (accessible by anyone)
class GameCharacter:
    def __init__(self, username):
        self.username = username

# 2. balance: private (not accessed directly outside the class)
class BankAccount:
    def __init__(self, balance):
        self.__balance = balance

# 3. engineCode: protected (class and its subclasses only)
class Vehicle:
    def __init__(self, engineCode):
        self._engineCode = engineCode

# 4. schoolName: public (safe for everyone to view and modify)
class Student:
    def __init__(self, schoolName):
        self.schoolName = schoolName

# 5. voterID: private (hidden for security reasons)
class VotingSystem:
    def __init__(self, voterID):
        self.__voterID = voterID
