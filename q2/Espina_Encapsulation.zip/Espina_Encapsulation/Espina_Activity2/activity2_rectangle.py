class Rectangle:
    def __init__(self, width, height):
        self.__width = width
        self.__height = height

    # width: getter, setter, deleter
    @property
    def width(self):
        return self.__width

    @width.setter
    def width(self, new_width):
        if new_width > 0:
            self.__width = new_width
        else:
            print("Width must be greater than 0.")

    @width.deleter
    def width(self):
        del self.__width
        print("Width has been deleted")

    # height: getter, setter, deleter
    @property
    def height(self):
        return self.__height

    @height.setter
    def height(self, new_height):
        if new_height > 0:
            self.__height = new_height
        else:
            print("Height must be greater than 0.")

    @height.deleter
    def height(self):
        del self.__height
        print("Height has been deleted")


rectangle = Rectangle(3, 4)

# Getters: used like regular attributes (no parentheses)
print(rectangle.width)
print(rectangle.height)

# Setters: used like assignment
rectangle.width = 5
rectangle.height = 6
print(rectangle.width)
print(rectangle.height)

# Invalid value is rejected by the setter
rectangle.width = -2
print(rectangle.width)

# Deleters
del rectangle.width
del rectangle.height
